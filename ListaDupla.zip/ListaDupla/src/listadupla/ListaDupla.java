/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadupla;

/**
 *
 * @author AndreyFernandesTraja
 */
public class ListaDupla {
    
   public Nodo prim;
   public Nodo ult;
   
   public ListaDupla()
   {
       this.prim = null;
       this.ult = null;
   }
   
   public boolean isEmpty()
   {
       if(this.prim == null)
       {
           return true;
       }
       else
       {
           return false;
       }
   }
   
   public void mostraLista()
   {
       Nodo nodoAux = this.prim;
       
       while (nodoAux != null)
       {
           nodoAux.mostraNodo();
           nodoAux = nodoAux.next;
       }
   }
   
   public void insereInicio(int dado)
   {
       // 1 - Criar nodo
       // 2 - Verificar se a lista isEmpty => V => alterar o ult 
       //                                  => F => alterar prev do prim
       // 3 - Alterar prim
       Nodo novoNodo = new Nodo(dado);
        
        if(this.isEmpty())
        {
            this.ult = novoNodo;
        }
        else
        {
            this.prim.prev = novoNodo;
        }
        novoNodo.next = this.prim;
        this.prim = novoNodo;
   } // fim método insereInicio
   
   public void insereFim(int dado)
   {
       // 1 - Criar nodo
       // 2 - Verifica se a lista isEmpty
       //  => V => altera prim
       //  => F => altera next do ult
       // 3 - Altera ult
       
       Nodo novoNodo = new Nodo(dado);
       
       if(this.isEmpty())
       {
           this.prim = novoNodo;
       }
       else
       {
           this.ult.next = novoNodo;
       }
       
       novoNodo.prev = this.ult;
       this.ult = novoNodo;
   } //fim método insereFim
}
