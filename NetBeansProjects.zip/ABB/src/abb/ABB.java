/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abb;

/**
 *
 * @author AndreyFernandesTraja
 */
public class ABB {
    
    private Nodo raiz;
    
    public ABB()
    {
        this.raiz = null;
    }
    
    public Nodo getRaiz()
    {
        return this.raiz;
    }
    
    public boolean isEmpty()
    {
        if (this.raiz == null)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public Nodo procura(int dado)
    {
        Nodo nodoAux = this.raiz;
        
        if(this.isEmpty())
        {
            return null;
        }
        while(dado != nodoAux.dado)
        {
            if(dado<nodoAux.dado)
            {
                nodoAux = nodoAux.esq;
            }
            else
            {
                nodoAux = nodoAux.dir;
            }
            
            if(nodoAux==null)
            {
                return null;
            }
        }
        return nodoAux;
    }
    
    public void insere(int dado)
    {
        if(this.procura(dado) == null)
        {
            Nodo novoNodo = new Nodo(dado);
            
            if(this.raiz == null)
            {
                this.raiz = novoNodo;
            }
            else
            {
                Nodo nodoAux = this.raiz;
                Nodo nodoPai;
                boolean achou = false;
                
                while (!achou)
                {
                    nodoPai = nodoAux;
                    
                    if(dado < nodoAux.dado)
                    {
                        nodoAux = nodoAux.esq;
                        
                        if(nodoAux == null)
                        {
                            nodoPai.esq = novoNodo;
                            achou = true;
                        }
                    }
                    else
                    {
                        nodoAux = nodoAux.dir;
                        
                        if(nodoAux == null)
                        {
                            nodoPai.dir = novoNodo;
                            achou = true;
                        }
                    }
                } //while
            }
        }
        else
        {
            System.out.println("Dado já cadastrado");
        }
    } // método
    
    public boolean delete (int elemento)
	{
		Nodo nodoAtual = raiz;
		Nodo nodoAnterior = raiz;
		
		boolean filhoEsquerda = true;
		
		while (nodoAtual.dado != elemento)
		{
			nodoAnterior = nodoAtual;
			
			if (elemento < nodoAtual.dado)
			{
				filhoEsquerda = true;
				nodoAtual = nodoAtual.esq;
			}
			else
			{
				nodoAtual = nodoAtual.dir;
				filhoEsquerda = false;
			}
				
			
			if (nodoAtual == null)
				return false;
		}


		// encontrou o nodo
		
		// caso 1: n�o tem filhos
		//
		if ((nodoAtual.esq == null) && (nodoAtual.dir == null))
		{
		     if (nodoAtual == raiz)	
		         raiz = null;
		     else
		     {
		  		if (filhoEsquerda)
		  			nodoAnterior.esq = null;
		  		else
		  			nodoAnterior.dir = null;
		     }
		}
		// caso 2: tem um �nico filho
		else
		   if (nodoAtual.dir == null)
           {
		   	   if (nodoAtual == raiz)	
		   	       raiz = nodoAtual.esq;
		   	   else
		   	      if (filhoEsquerda)
		   	      		nodoAnterior.esq = nodoAtual.esq;
		   	      else
		   	      	    nodoAnterior.dir = nodoAtual.esq;	
		   	      	   
		    }
		    else
		      if (nodoAtual.esq == null)
		      {
		      	  if (nodoAtual == raiz)
		      	      raiz = nodoAtual.dir;
		      	  else
		      	    if (filhoEsquerda)
		      	        nodoAnterior.esq = nodoAtual.dir;
		      	    else
		      	        nodoAnterior.dir = nodoAtual.dir;
		      }
		      // caso3: tem 2 filhos
		      else
		      {
		      	Nodo sucessor = getSucessor(nodoAtual);
		      	
		      	if (nodoAtual == raiz)
		      	{
		      		raiz = sucessor;
		      	}
		      	else 
		      	  if (filhoEsquerda)
		      	  {
		      	  	nodoAnterior.esq = sucessor;
		      	  }
		      	  else
		      	  {
		      	  	nodoAnterior.dir = sucessor;
		      	  }
		      	  
		      	sucessor.esq = nodoAtual.esq;  
		      	  
		      }
		      return true;
		
	}
	
	private Nodo getSucessor(Nodo nodoExcluir)
	{
		Nodo paiSucessor = nodoExcluir;
		Nodo sucessor    = nodoExcluir;
		Nodo nodoAtual   = nodoExcluir.dir;
		
		while (nodoAtual != null)
		{
			paiSucessor = sucessor;
			sucessor    = nodoAtual;
			nodoAtual   = nodoAtual.esq;
		}
		
		if (sucessor != nodoExcluir.dir)
		{
			paiSucessor.esq = sucessor.dir;
			sucessor.dir    = nodoExcluir.dir;
		}
		
		return sucessor;
	}
        
        public void emOrdem(Nodo nodoAux)
        {
            if(nodoAux != null)
            {
                this.emOrdem(nodoAux.esq);
                System.out.println(nodoAux.dado);
                this.emOrdem(nodoAux.dir);
            }
        }
        
        public void PreOrdem(Nodo nodoAux)
        {
            if(nodoAux != null)
            {
                System.out.println(nodoAux.dado);
                this.PreOrdem(nodoAux.esq);
                this.PreOrdem(nodoAux.dir);
            }
        }
        
        public void PosOrdem(Nodo nodoAux)
        {
            if(nodoAux != null)
            {
                this.PosOrdem(nodoAux.esq);
                this.PosOrdem(nodoAux.dir);
                System.out.println(nodoAux.dado);
            }
        }
}
