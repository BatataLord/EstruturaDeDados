/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abb;

/**
 *
 * @author AndreyFernandesTraja
 */
public class abbAPP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ABB abb = new ABB();
        
        abb.insere(60);
        abb.insere(40);
        abb.insere(80);
        abb.insere(30);
        abb.insere(45);
        abb.insere(70);
        abb.insere(90);
        abb.insere(20);
        abb.insere(35);
        abb.insere(42);
        abb.insere(50);
        abb.insere(65);
        abb.insere(75);
        abb.insere(85);
        abb.insere(95);
        
        abb.emOrdem(abb.getRaiz());
        
        
        

        
        
    }
    
}
